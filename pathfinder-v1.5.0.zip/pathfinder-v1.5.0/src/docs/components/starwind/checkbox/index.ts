import Checkbox from "./Checkbox.astro";

export { Checkbox };

export default Checkbox;
