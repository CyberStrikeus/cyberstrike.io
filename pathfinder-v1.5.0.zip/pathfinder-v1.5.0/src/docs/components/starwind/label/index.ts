import Label from "./Label.astro";

export { Label };

export default Label;
