import Textarea from "./Textarea.astro";

export { Textarea };

export default Textarea;
