import Button from "./Button.astro";

export { Button };

export default Button;
