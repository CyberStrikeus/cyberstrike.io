import Input from "./Input.astro";

export { Input };

export default Input;
