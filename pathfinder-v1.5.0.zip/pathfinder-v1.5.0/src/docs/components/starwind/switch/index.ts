import Switch from "./Switch.astro";
import type { SwitchChangeEvent } from "./SwitchTypes";

export { Switch, type SwitchChangeEvent };

export default Switch;
