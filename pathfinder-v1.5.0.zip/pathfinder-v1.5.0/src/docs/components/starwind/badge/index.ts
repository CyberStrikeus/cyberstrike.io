import Badge from "./Badge.astro";

export { Badge };

export default Badge;
